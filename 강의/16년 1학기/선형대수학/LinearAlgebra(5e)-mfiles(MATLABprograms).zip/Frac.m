function frac(P)
%FRAC
%Gives matrix with elements in rational form.
%Calling format: frac(A)

rats(P)

