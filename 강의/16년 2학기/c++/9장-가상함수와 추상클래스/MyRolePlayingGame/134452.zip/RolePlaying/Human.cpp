#include "Human.h"

Human::Human(){
	type=0;
	strength=10;
	hitpoints=10;
	distance=1;
}

int Human::getDamage(){
	int damage;
	damage = (rand() %strength) + 1;
	cout << getSpecies() << "attaks for" << damage << "points!" << endl;
	return damage;
}

void Human::move(){
	char move;
	cin>>move;
	switch(move){
		case 'a': if(x>1)x--;
		break;
		case 's': if(y>1)y--;
		break;
		case 'd': if(y<10)y++;
		break;
		case 'f': if(x<20)x++;
		break;
		case 'g':;
		break;
	}
}

char Human::getShape(){
	return 'H';
}