#ifndef BALROG_H
#define BALROG_H

#include "Demon.h"
class Balrog : public Demon{
public:
	Balrog();
	int getDamage();
	void move();
	char getShape();
};

#endif //