#ifndef CYBER_DEMON_H
#define CYBER_DEMON_H

#include "Demon.h"
class Cyber_demon : public Demon{
public:
	Cyber_demon();
	int getDamage();
	void move();
	char getShape();
};

#endif //