#include "Creature.h"
#include <istream>
using namespace std;

Creature::Creature(){
	type=0;
	strength=10;
	hitpoints=10;
	distance=1;
	x=rand()%20+1;
	y=rand()%10+1;
}

string Creature::getSpecies(){
	switch(type)
		{
			case 0: return "Human";
			case 1: return "Cyberdemon";
			case 2: return "Balrog";
			case 3: return "Elf";
		}
			return "Unknown";
}

void Creature::collide(Creature *p){
	if(this->x==p->getX() && this->y==p->getY()){
		this->hitpoints-=p->getDamage();
		p->hitpoints-=this->getDamage();
		cout<<this->getSpecies()<<" : Strength "<<this->getStrength()<<" HitPoint "<<this->getHitpoints()<<endl;
		cout<<p->getSpecies()<<" : Strength "<<p->getStrength()<<" HitPoint "<<p->getHitpoints()<<endl;
	}
}

int Creature::getHitpoints(){
	return hitpoints;
}
int Creature::getStrength(){
	return strength;
}
void Creature::setHitpoints(int h){
	this->hitpoints+=h;
	cout<<"HP"<<h<<" UP!!"<<endl;
}
void Creature::setStreangth(int s){
	this->strength+=s;
	cout<<"Strength"<<s<<" UP!!"<<endl;
}