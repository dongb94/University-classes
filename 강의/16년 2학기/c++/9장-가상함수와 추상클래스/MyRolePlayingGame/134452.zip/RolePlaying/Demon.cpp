#include "Demon.h"

Demon::Demon(){
	type=1;
	strength=10;
	hitpoints=10;
	distance=2;
	x=rand()%20+1;
	y=rand()%10+1;
}

int Demon::getDamage(){
	int damage;
	damage = (rand() %strength) + 1;
	cout << getSpecies() << "attaks for" << damage << "points!" << endl;
	if((rand()%100)<5)
	{
		damage = damage + 50;
		cout << "Demonic attack inflicts 50"
			<< " additional damage points!" << endl;
	}
	return damage;
}