#ifndef DEMON_H
#define DEMON_H

#include "Creature.h"
class Demon : public Creature{
public:
	Demon();
	virtual void move()=0;
	virtual int getDamage()=0;
};

#endif //