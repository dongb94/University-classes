#ifndef ELF_H
#define ELF_H

#include "Creature.h"
class Elf : public Creature{
public:
	Elf();
	int getDamage();
	void move();
	char getShape();
};

#endif //