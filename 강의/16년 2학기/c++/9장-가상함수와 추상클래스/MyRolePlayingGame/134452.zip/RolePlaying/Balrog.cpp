#include "Balrog.h"

Balrog::Balrog(){
	type=2;
	strength=10;
	hitpoints=10;
	distance=2;
	x=rand()%20+1;
	y=rand()%10+1;
}
int Balrog::getDamage(){
	int damage;
	damage = (rand() %strength) + 1;
	cout << getSpecies() << "attaks for" << damage << "points!" << endl;
	if((rand()%100)<5)
	{
		damage = damage + 50;
		cout << "Demonic attack inflicts 50"
		<< " additional damage points!" << endl;
	}
	int damage2 = (rand()%strength) +1;
	cout << "Balrog speed attack inflicts "<< damage2 << " additional damage points!"<<endl;
	damage+=damage2;
	return damage;
}

void Balrog::move(){
	int d=rand();
	if(d%100<25)
		if(x<19)x+=distance;
		else x-=distance;
	else if(d%100<50)
		if(x>2)x-=distance;
		else x+=distance;
	else if(d%100<75)
		if(y>2)y-=distance;
		else y+=distance;
	else
		if(y<9)y+=distance;
		else y-=distance;
}

char Balrog::getShape(){
	return 'B';
}