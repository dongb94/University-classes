#ifndef HUMAN_H
#define HUMAN_H

#include "Creature.h"
class Human : public Creature{
public:
	Human();
	int getDamage();
	void move();
	char getShape();
};

#endif //