//Virtual�� �� �Լ� = Creature.h�� getDamage(), move(), getShape(), �Ҹ���
#include <iostream>
using namespace std;
#include "Human.h"
#include "Balrog.h"
#include "Cyber_demon.h"
#include "Elf.h"

void Board(){
	Elf e;
	Human h;
	Cyber_demon c;
	Balrog b;
	int HP=1,DP=1;
	int type=0;
	bool gameover=true;	//false�� ���� ����
	while(gameover){
		for(int i=1; i<=10; i++){
			for(int j=1; j<=20; j++){
				if(e.getX()==j&&e.getY()==i&&e.getHitpoints()>0)	cout<<e.getShape();
				else if(c.getX()==j&&c.getY()==i&&c.getHitpoints()>0)	cout<<c.getShape();
				else if(b.getX()==j&&b.getY()==i&&b.getHitpoints()>0)	cout<<b.getShape();
				else if(h.getX()==j&&h.getY()==i&&h.getHitpoints()>0)	cout<<h.getShape();
				else if(HP==1&&i==5&&j==5)	cout<<'h';
				else if(DP==1&&i==7&&j==10)	cout<<'p';
				else cout<<'-';
			}
			cout<<endl;
		}
		e.move();
		h.move();
		c.move();
		b.move();
		if(e.getHitpoints()>0) h.collide(&e);
		if(c.getHitpoints()>0) h.collide(&c);
		if(b.getHitpoints()>0) h.collide(&b);

		if(HP==1&&h.getX()==5&&h.getY()==5){
			h.setHitpoints(20);
			HP=0;
		}
		if(DP==1&&h.getX()==10&&h.getY()==7){
			h.setStreangth(50);
			DP=0;
		}

		if(h.getHitpoints()<=0){
			cout<<"YOU DIE!!";
			gameover=false;
			break;
		}
		if(e.getHitpoints()<=0&&c.getHitpoints()<=0&&b.getHitpoints()<=0){
			cout<<"YOU WIN!!";
			gameover=false;
		}
	}
}

int main(void){
	Board();
	return 0;
}

