
#include "Elf.h"

Elf::Elf(){
	type=3;
	strength=3;
	hitpoints=10;
	distance=2;
	x=rand()%20+1;
	y=rand()%10+1;
}

int Elf::getDamage(){
	int damage;
	damage = (rand() %strength) + 1;
	cout << getSpecies() << "attaks for" << damage << "points!" << endl;
	if((rand()%10) == 0){
		cout<<"Madical attack inflicts " << damage << " additional damage points!"<<endl;
		damage *= 2;
	}
	return damage;
}
void Elf::move(){
	int d=rand();
	if(d%100<25)
		if(x<19)x+=distance;
		else x-=distance;
	else if(d%100<50)
		if(x>2)x-=distance;
		else x+=distance;
	else if(d%100<75)
		if(y>2)y-=distance;
		else y+=distance;
	else
		if(y<9)y+=distance;
		else y-=distance;
}
char Elf::getShape(){
	return 'E';
}