#include <iostream>
using namespace std;

void swapArray(int *p, int *q, int size);
void printArray(int *p, int size);

int main(){
	int a[]={1,2,3,4,5};
	int b[]={9,8,7,6,5};

	cout<<"�迭 a = ";
	printArray(a,5);
	cout<<"�迭 b = ";
	printArray(b,5);

	swapArray(a,b,5);

	cout<<"�迭 a = ";
	printArray(a,5);
	cout<<"�迭 b = ";
	printArray(b,5);

	return 0;
}


void swapArray(int *p, int *q, int size){
	cout<<"swapArray() ����..."<<"\n";
	
	for(int i=0; i<size; i++){
		int tmp=*(p+i);
		*(p+i)=*(q+i);
		*(q+i)=tmp;
	}

}

void printArray(int *p, int size){
	for(int i=0; i<size ; i++){
		cout<<*(p+i)<<" ";
	}
	cout<<"\n";
}