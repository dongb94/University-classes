#include <iostream>
using namespace std;

void print_star(int m){
		for(int j=0; j<m; j++){
			cout<<"*";
		}
		cout<<"\n";
}
int main(){
	int num;
	cout<<"�����Է�>>";
	cin>>num;

	for(int i=num; i>0; i--){
		print_star(i);
	}
	return 0;
}

