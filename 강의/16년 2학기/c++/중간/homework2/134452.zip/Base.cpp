#include <iostream>
using namespace std;

#include "Exp.h"
Exp::Exp(){
	base=1;
	exp=1;
}
Exp::Exp(int b){
	base=b;
	exp=1;
}
Exp::Exp(int b, int e){
	base=b;
	exp=e;
}
int Exp::getValue(){
		int value=base;
		for(int i=2; i<=exp; i++){
			value*=base;
		}
		return value;
}
int Exp::getBase(){
	return base;
}
int Exp::getExp(){
	return exp;
}
bool Exp::equals(Exp b){
	bool exp_equals;
	if(getValue()==b.getValue())
		exp_equals=true;
	else exp_equals=false;

	return exp_equals;
}

Exp::~Exp(){}